import { useState } from "react";

function Header(props) {
  const [selected, setSelected] = useState(true);
  const signed = () => {
    setSelected(!selected);
    props.setLike();
  };
  const wCategoryButton = () => {
    props.setCtW();
  };
  const mCategoryButton = () => {
    props.setCtM();
  };

  return (
    <header>
      <div className="title">
        <button className="women" onClick={wCategoryButton}>
          Women's clothing
        </button>
        <button className="men" onClick={mCategoryButton}>
          men's clothing
        </button>
        <button>jewelery</button>
        <button>electronics</button>
      </div>
      <div className="logo">
        <h1>Online-Shopping</h1>
      </div>
      <div className="search">
        <input type="text" value="search" id="search" placeholder="Search" />
        <button class="btn" type="submit">
          Search
        </button>
        <i class="fa-solid fa-cart-shopping"></i>
        <span className="quantityT">{props.qt}</span>
        {/* <button
          className={`sign-in ${selected ? "" : "sign-out"}`}
          onClick={signed}
        >
          {selected ? "Sign In" : "Sign Out"}
        </button> */}
        {selected ? (
          <button className="sign-in" onClick={signed}>
            Sign In
          </button>
        ) : (
          <button className="sign-out" onClick={signed}>
            Sign Out
          </button>
        )}
      </div>
    </header>
  );
}

export default Header;
