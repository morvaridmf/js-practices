import "./App.css";
import { useEffect, useState } from "react";
import Footer from "./components/Footer";
import Header from "./components/Header";
import Card from "./components/Card";
import CardOld from "./components/Card-old";
import "bootstrap-icons/font/bootstrap-icons.css";
import "@fortawesome/fontawesome-free/css/all.min.css";

function App() {
  let [womenProducts, setWomenProducts] = useState([]);
  let [menProducts, setMenProducts] = useState([]);
  let [jeweleryProducts, setJeweleryProducts] = useState([]);
  // let [electronicsProducts, setElectronicsProducts] = useState([]);
  const [quantityTotal, setQuantityTotal] = useState(0);
  const [likeStatus, setLikeStatus] = useState(false);

  useEffect(() => {
    fetch("https://fakestoreapi.com/products/category/jewelery")
      .then((res) => res.json())
      .then((data) => setJeweleryProducts(data))
      .catch((error) => console.log(error));
  }, []);

  function categorywomen() {
    fetch("https://fakestoreapi.com/products/category/women's clothing")
      .then((res) => res.json())
      .then((data) => setWomenProducts(data))
      .catch((error) => console.log(error));
  }
  function categorymen() {
    fetch("https://fakestoreapi.com/products/category/men's clothing")
      .then((res) => res.json())
      .then((data) => setMenProducts(data))
      .catch((error) => console.log(error));
  }

  // fetch("https://fakestoreapi.com/products/category/women's%20clothing=8")
  //   .then((res) => res.json())
  //   .then((data) => setElectronicsProducts(data))
  //   .catch((error) => console.log(error));

  const calculateQuantity = () => {
    setQuantityTotal(quantityTotal + 1);
  };
  const likeButton = () => {
    setLikeStatus(!likeStatus);
  };

  return (
    <div className="App">
      <Header
        qt={quantityTotal}
        setLike={likeButton}
        setCtW={categorywomen}
        setCtM={categorymen}
      />

      <section className="cards">
        {womenProducts.length ? (
          womenProducts.map((item) => (
            <Card
              setQt={calculateQuantity}
              likeB={likeStatus}
              image={item.image}
              title={item.title}
              price={item.price}
            />
          ))
        ) : (
          <h1>Loading...</h1>
        )}
        {menProducts.length ? (
          menProducts.map((item) => (
            <Card
              setQt={calculateQuantity}
              likeB={likeStatus}
              image={item.image}
              title={item.title}
              price={item.price}
            />
          ))
        ) : (
          <h1>Loading...</h1>
        )}
      </section>
      <br></br>
      <h1 className="sale">Items in sale </h1>
      <section className="cards-old">
        {jeweleryProducts.map((item) => (
          <CardOld
            setQt={calculateQuantity}
            image={item.image}
            title={item.title}
            price={item.price}
          />
        ))}
      </section>

      <Footer />
    </div>
  );
}

export default App;
