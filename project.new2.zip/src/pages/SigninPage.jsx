import React from "react";
import SignInForm from "../components/Sign-in";

function SignInPage() {
  return (
    <div>
      <SignInForm />
    </div>
  );
}

export default SignInPage;
