
function Footer(){
    return(
     <footer>
    <span>
      <p className="copy">
        &copy; Copyright 2018 World Wide Marketing, Copyright Registration.
      </p>
    </span>
  </footer>
    )
};

export default Footer;