import "./App.css";
import { useState } from "react";
import Footer from "./components/Footer";
import Header from "./components/Header";
import Card from "./components/Card";
import CardOld from "./components/Card-old";
import "bootstrap-icons/font/bootstrap-icons.css";
import "@fortawesome/fontawesome-free/css/all.min.css";

import pic5 from "./assets/image-5.jpg";
import pic6 from "./assets/image-6.jpg";
import pic7 from "./assets/image-7.jpg";
import pic8 from "./assets/image-8.jpg";

const productsOld = [
  {
    image: pic5,
    title: "Lorem ipsum dolor sit amet consectetur",
    newprice: 7,
    oldprice: 10,
  },
  {
    image: pic6,
    title: "Lorem ipsum dolor sit amet consectetur",
    newprice: 11,
    oldprice: 15,
  },
  {
    image: pic7,
    title: "Lorem ipsum dolor sit amet consectetur",
    newprice: 17,
    oldprice: 20,
  },
  {
    image: pic8,
    title: "Lorem ipsum dolor sit amet Lorem ipsum dolor ",
    newprice: 14,
    oldprice: 17,
  },
];

function App() {
  const categorywomen = () => {
    let [womenProducts, setWomenProducts] = useState([]);
    fetch("https://fakestoreapi.com/products/category/women's%20clothing=8")
      .then((res) => res.json())
      .then((data) => setWomenProducts(data))
      .catch((error) => console.log(error));
  };

  let [menProducts, setMenProducts] = useState([]);
  fetch("https://fakestoreapi.com/products/category/women's%20clothing=8")
    .then((res) => res.json())
    .then((data) => setMenProducts(data))
    .catch((error) => console.log(error));

  let [jewelleryProducts, setJewelleryProducts] = useState([]);
  fetch("https://fakestoreapi.com/products/category/women's%20clothing=8")
    .then((res) => res.json())
    .then((data) => setJewelleryProducts(data))
    .catch((error) => console.log(error));

  let [electronicsProducts, setElectronicsProducts] = useState([]);
  fetch("https://fakestoreapi.com/products/category/women's%20clothing=8")
    .then((res) => res.json())
    .then((data) => setElectronicsProducts(data))
    .catch((error) => console.log(error));

  const [quantityTotal, setQuantityTotal] = useState(0);
  const [likeStatus, setLikeStatus] = useState(false);
  // const [category, setCategory] = useState([]);
  const calculateQuantity = () => {
    setQuantityTotal(quantityTotal + 1);
  };
  const likeButton = () => {
    setLikeStatus(!likeStatus);
  };

  return (
    <div className="App">
      <Header qt={quantityTotal} setLike={likeButton} setCt={categorywomen} />

      <section className="cards">
        {womenProducts.map((item) => (
          <Card
            setQt={calculateQuantity}
            likeB={likeStatus}
            image={item.image}
            title={item.title}
            price={item.price}
          />
        ))}
      </section>
      <br></br>
      <h1 className="sale">Items in sale </h1>
      <section className="cards-old">
        {productsOld.map((item) => (
          <CardOld
            setQt={calculateQuantity}
            image={item.image}
            title={item.title}
            newprice={item.newprice}
            oldprice={item.oldprice}
          />
        ))}
      </section>

      <Footer />
    </div>
  );
}

export default App;
